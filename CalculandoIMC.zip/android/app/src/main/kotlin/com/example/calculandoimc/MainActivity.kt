package com.example.calculandoimc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
